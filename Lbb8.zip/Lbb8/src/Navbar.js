import React, { useState, useEffect } from 'react';
import { FaBars } from 'react-icons/fa';
import logo from './logo.svg';
import Sidebar from './Sidebar';

const Navbar = () => {
  const [showLinks, setShowLinks] = useState(false);

  useEffect(() => {
    const showMenu = () => {
      if (window.innerWidth > 800) {
        setShowLinks(true);
      } else {
        setShowLinks(false);
      }
    };

    // Встановлюємо початковий стан при завантаженні сторінки
    showMenu();

    // Додаємо обробник події зміни розміру вікна
    window.addEventListener('resize', showMenu);

    // Очищення обробника подій при розмонтуванні компонента
    return () => {
      window.removeEventListener('resize', showMenu);
    };
  }, []);

  return (
    <nav>
      <div className="nav-center">
        <div className="nav-header">
          <img src={logo} alt="logo" />
          <button
            className="nav-toggle"
            onClick={() => setShowLinks(!showLinks)}
          >
            <FaBars />
          </button>
        </div>

        {/* Відображення компонента Sidebar за умовою */}
        {showLinks && <Sidebar />}
      </div>
    </nav>
  );
};

export default Navbar;