const data = [
  {
    id: 'rec61x68y095scCRE',
    name: 'Best of Paris In 7 Days Tour',
    info: 'Paris is a world capital of art, fashion, gastronomy and culture. Its 19th-century cityscape is crossed by wide boulevards and the River Seine. Beyond such landmarks as the Eiffel Tower and the 12th-century, Gothic Notre-Dame cathedral, the city is known for its cafe culture and designer boutiques along the Rue du Faubourg Saint-Honoré.',
    image: 'https://www.course-api.com/images/tours/tour-1.jpeg',
    price: '1,995'
  },
  {
    id: 'rec172128E3255160',
    name: 'Best of Ireland Tour',
    info: 'Rick Steves Best of Ireland tour kicks off with the best of Dublin, followed by Ireland highlights: Rock of Cashel, Kinsale, Dingle Peninsula, Cliffs of Moher, Aran Islands, Connemara, Shannon, and the Boyne Valley.',
    image: 'https://www.course-api.com/images/tours/tour-2.jpeg',
    price: '3,895'
  },
  {
    id: 'recA81832128E325',
    name: 'Best of Salzburg & Vienna In 8 Days',
    info: 'Let’s go with the flow on this Austrian adventure, where we’ll take in the classical sounds of Mozart and Strauss, sample local delicacies, and marvel at breathtaking mountain and alpine lake scenery.',
    image: 'https://www.course-api.com/images/tours/tour-3.jpeg',
    price: '2,695'
  }
];

export default data;